#pragma once

#include "Memory.h"
#include "Patch.h"
#include "Logger.h"


Logger logger;
Memory memory;
Patch patch;

