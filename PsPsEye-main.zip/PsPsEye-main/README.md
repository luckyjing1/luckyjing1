# PsPsEye
PsPsEye is a simple memory based bot for the online MMORPG ConquerOnline. This is not the best bot you can find
in the market but it provides a starting point for more complex bots.
## Features

- Auto hunting.
- Auto looting.
- supports all melee heroes.
- supports targeted, untargeted and self skills.
- supports XP skills (right now it supports fatal strike and superman).
- auto revive.
- fully functional Path finding system (actually it uses the one implemented by the game :P).
- farms about 250k gold per hour.

## HOW TO USE
type the command "@start [HeroType]" in the chat box with talk functionality selected, make sure the target name is empty.
if HeroType is not supplied, it defaults to Warrior.

## Demo
https://www.youtube.com/watch?v=8z12WyaX5hk
